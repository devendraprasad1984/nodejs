export default interface IBook {
    id: number;
    author: string;
    title: string;
}
