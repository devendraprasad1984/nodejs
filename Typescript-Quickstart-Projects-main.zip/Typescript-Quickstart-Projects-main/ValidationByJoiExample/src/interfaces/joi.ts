export interface IJoiData {
    username: string;
    password: string;
    email: string;
    birth_year?: number;
}
